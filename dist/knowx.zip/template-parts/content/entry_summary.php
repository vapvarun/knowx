<?php
/**
 * Template part for displaying a post's summary
 *
 * @package knowx
 */

namespace Knowx\Knowx;

?>

<div class="entry-summary">
	<?php the_excerpt(); ?>
</div><!-- .entry-summary -->
