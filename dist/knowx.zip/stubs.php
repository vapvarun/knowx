<?php

class WP_Widget {
	public function __construct( $id_base = '', $name = '', $widget_options = [], $control_options = [] ) {}
	public function widget( $args, $instance ) {}
	public function update( $new_instance, $old_instance ) {}
	public function form( $instance ) {}
}
